# Tool to measure amount of fees paid to layer zero

## installation and setup
- `npm i`  
- fill `addresses.txt` and `proxies.txt`

## running
`npm run start`

## Donos and contact

> telegram: **https://t.me/findmeonchain**  
donos: **[0x00000c7c61c5d7fbbf217ab9fc64f6016390d4ba](https://debank.com/profile/0x00000c7c61c5d7fbbf217ab9fc64f6016390d4ba)**